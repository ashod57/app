package com.my.newproject8;

import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.EditText;
import android.widget.CheckBox;
import android.widget.Button;
import android.widget.ImageView;
import android.content.Intent;
import android.net.Uri;
import android.app.Activity;
import android.content.SharedPreferences;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.view.View;

public class MainActivity extends AppCompatActivity {
	
	
	private Toolbar _toolbar;
	private double k = 0;
	private String a = "";
	
	private LinearLayout linear2;
	private LinearLayout linear3;
	private LinearLayout linear4;
	private LinearLayout linear5;
	private LinearLayout linear6;
	private LinearLayout linear7;
	private LinearLayout linear8;
	private LinearLayout linear9;
	private TextView textview2;
	private EditText edittext2;
	private TextView textview3;
	private EditText edittext3;
	private TextView textview4;
	private EditText edittext4;
	private TextView textview5;
	private EditText edittext5;
	private CheckBox checkbox1;
	private Button button1;
	private ImageView imageview2;
	
	private Intent i = new Intent();
	private SharedPreferences userdata;
	private AlertDialog.Builder dialogue;
	private SharedPreferences data;
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.main);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		_toolbar = (Toolbar) findViewById(R.id._toolbar);
		setSupportActionBar(_toolbar);
		getSupportActionBar().setDisplayHomeAsUpEnabled(true);
		getSupportActionBar().setHomeButtonEnabled(true);
		_toolbar.setNavigationOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) {
				onBackPressed();
			}
		});
		linear2 = (LinearLayout) findViewById(R.id.linear2);
		linear3 = (LinearLayout) findViewById(R.id.linear3);
		linear4 = (LinearLayout) findViewById(R.id.linear4);
		linear5 = (LinearLayout) findViewById(R.id.linear5);
		linear6 = (LinearLayout) findViewById(R.id.linear6);
		linear7 = (LinearLayout) findViewById(R.id.linear7);
		linear8 = (LinearLayout) findViewById(R.id.linear8);
		linear9 = (LinearLayout) findViewById(R.id.linear9);
		textview2 = (TextView) findViewById(R.id.textview2);
		edittext2 = (EditText) findViewById(R.id.edittext2);
		textview3 = (TextView) findViewById(R.id.textview3);
		edittext3 = (EditText) findViewById(R.id.edittext3);
		textview4 = (TextView) findViewById(R.id.textview4);
		edittext4 = (EditText) findViewById(R.id.edittext4);
		textview5 = (TextView) findViewById(R.id.textview5);
		edittext5 = (EditText) findViewById(R.id.edittext5);
		checkbox1 = (CheckBox) findViewById(R.id.checkbox1);
		button1 = (Button) findViewById(R.id.button1);
		imageview2 = (ImageView) findViewById(R.id.imageview2);
		userdata = getSharedPreferences("userdata", Activity.MODE_PRIVATE);
		dialogue = new AlertDialog.Builder(this);
		data = getSharedPreferences("data", Activity.MODE_PRIVATE);
		
		button1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (!edittext2.getText().toString().equals("")) {
					if (!edittext3.getText().toString().equals("")) {
						if (!edittext4.getText().toString().equals("")) {
							if (!edittext5.getText().toString().equals("")) {
								if (checkbox1.isChecked()) {
									userdata.edit().putString("name", edittext2.getText().toString()).commit();
									userdata.edit().putString("address", edittext3.getText().toString()).commit();
									userdata.edit().putString("locality", edittext4.getText().toString()).commit();
									userdata.edit().putString("place", edittext5.getText().toString()).commit();
									i.setClass(getApplicationContext(), FirstActivity.class);
									startActivity(i);
								}
								else {
									SketchwareUtil.showMessage(getApplicationContext(), "Check the claims ");
								}
							}
							else {
								SketchwareUtil.showMessage(getApplicationContext(), "Enter your District");
							}
						}
						else {
							SketchwareUtil.showMessage(getApplicationContext(), "Enter your locality");
						}
					}
					else {
						SketchwareUtil.showMessage(getApplicationContext(), "Enter your address ");
					}
				}
				else {
					SketchwareUtil.showMessage(getApplicationContext(), "Enter your name ");
				}
			}
		});
		
		imageview2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				SketchwareUtil.showMessage(getApplicationContext(), "LOGO OF OUR MOTIVE");
			}
		});
	}
	private void initializeLogic() {
		if (!userdata.getString("name", "").equals("")) {
			i.setClass(getApplicationContext(), FirstActivity.class);
			startActivity(i);
		}
		else {
			
		}
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
